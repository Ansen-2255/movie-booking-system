<?php
header('Location: homepage2.php');
exit;
