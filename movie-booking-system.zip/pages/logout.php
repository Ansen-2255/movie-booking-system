<?php
require_once 'db.php'; session_destroy(); header('Location: homepage2.php'); exit;
